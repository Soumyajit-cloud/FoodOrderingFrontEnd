let cart = [];
const orderHistory = [];
let total = 0;
let popUp = document.getElementById("cart-popup");
let indexI = 1;

function openCartPopUp() {
    const card = document.getElementById('cart-popup');
    card.style.display = 'block';
}

function closeCart() {
    const card = document.getElementById('cart-popup');
    card.style.display = 'none';
}

function showMenu(){
    const card = document.getElementById('card');
    card.style.display = 'block';
}

function hideMenu() {
    const card = document.getElementById('card');
    card.style.display = 'none';
}

function addToCart(itemName, itemPrice) {
    const existingItem = cart.find(item => item.name === itemName);

    if (existingItem) {
        existingItem.quantity++;
    } else {
        cart.push({
            name: itemName,
            price: itemPrice,
            quantity: 1
        });
    }

    updateCart();
}

function updateCart() {
    const cartItems = document.getElementById("cart-items");
    cartItems.innerHTML = "";
    cart.forEach((item, index) => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${index + 1}</td>
            <td>${item.name}</td>
            <td>${item.price.toFixed(2)}</td>
            <td>${item.quantity}</td>
            <td>
                <button onclick="deleteCartItem(${index})">Delete</button>
            </td>
            `;
        cartItems.appendChild(row);
    });
}

function deleteCartItem(index) {
    cart.splice(index, 1);
    updateCart();
}

function modifyCartItem(index) {
    // Implement modification logic here
}

function checkout() {
    orderHistory.unshift({
        status: "Completed",
        title: "Order " + indexI ,
        quantity: 2
    });
    cart = [];
    indexI = indexI+1;
    updateOrderHistory();
}

function updateOrderHistory() {
    const orderHistoryItems = document.getElementById("order-history-items");
    orderHistoryItems.innerHTML = "";

    orderHistory.forEach((order, index) => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${index + 1}</td>
            <td>${order.status}</td>
            <td>${order.title}</td>
            <td>
                <button onclick="deleteOrderHistoryItem(${index})">Delete</button>
                <button onclick="modifyOrderHistoryItem(${index})">Modify</button>
            </td>
        `;
        orderHistoryItems.appendChild(row);
    });
}

function deleteOrderHistoryItem(index) {
    orderHistory.splice(index, 1);
    updateOrderHistory();
}

function modifyOrderHistoryItem(index) {
    // Implement modification logic here
}

updateCart();
updateOrderHistory();

